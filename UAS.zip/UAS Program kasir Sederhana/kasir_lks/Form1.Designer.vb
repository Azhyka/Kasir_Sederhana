﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.PanelMenu = New System.Windows.Forms.Panel()
        Me.btnLogout = New System.Windows.Forms.Button()
        Me.btnAkun = New System.Windows.Forms.Button()
        Me.btnStok = New System.Windows.Forms.Button()
        Me.btnKasir = New System.Windows.Forms.Button()
        Me.btnBeranda = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.PanelLogin = New System.Windows.Forms.Panel()
        Me.btnLogin = New System.Windows.Forms.Button()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.PanelBeranda = New System.Windows.Forms.Panel()
        Me.DateBerandaAkhir = New System.Windows.Forms.DateTimePicker()
        Me.DateBerandaAwal = New System.Windows.Forms.DateTimePicker()
        Me.ViewBerandaLaporan = New System.Windows.Forms.DataGridView()
        Me.txtBerandaIdAkun = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.BtnBerandaRefresh = New System.Windows.Forms.Button()
        Me.BtnBerandaFilter = New System.Windows.Forms.Button()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.LabelBerandaJumlahTransaksi = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.labelWelcome = New System.Windows.Forms.Label()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PanelKasir = New System.Windows.Forms.Panel()
        Me.txtKasirIdTransaksi = New System.Windows.Forms.TextBox()
        Me.viewKasir = New System.Windows.Forms.DataGridView()
        Me.btnKasirRefresh = New System.Windows.Forms.Button()
        Me.txtKasirUang = New System.Windows.Forms.TextBox()
        Me.txtKasirIdItem = New System.Windows.Forms.TextBox()
        Me.txtKasirKode = New System.Windows.Forms.TextBox()
        Me.btnKasirHapus = New System.Windows.Forms.Button()
        Me.btnNewKasir = New System.Windows.Forms.Button()
        Me.btnKasirTambah = New System.Windows.Forms.Button()
        Me.btnKasirBayar = New System.Windows.Forms.Button()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.labelHargaTotal = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.PanelStok = New System.Windows.Forms.Panel()
        Me.btnProdukRefresh = New System.Windows.Forms.Button()
        Me.txtProdukHarga = New System.Windows.Forms.TextBox()
        Me.txtProdukJumlah = New System.Windows.Forms.TextBox()
        Me.txtProdukNama = New System.Windows.Forms.TextBox()
        Me.txtProdukKode = New System.Windows.Forms.TextBox()
        Me.btnProdukHapus = New System.Windows.Forms.Button()
        Me.btnProdukEdit = New System.Windows.Forms.Button()
        Me.btnProdukSimpan = New System.Windows.Forms.Button()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.viewProduk = New System.Windows.Forms.DataGridView()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.PanelAkun = New System.Windows.Forms.Panel()
        Me.btnAkunRefresh = New System.Windows.Forms.Button()
        Me.txtAkunId = New System.Windows.Forms.TextBox()
        Me.txtAkunJabatan = New System.Windows.Forms.TextBox()
        Me.txtAkunPassword = New System.Windows.Forms.TextBox()
        Me.txtAkunUsername = New System.Windows.Forms.TextBox()
        Me.txtAkunNama = New System.Windows.Forms.TextBox()
        Me.btnAkunHapus = New System.Windows.Forms.Button()
        Me.btnAkunEdit = New System.Windows.Forms.Button()
        Me.btnAkunSimpan = New System.Windows.Forms.Button()
        Me.viewAkun = New System.Windows.Forms.DataGridView()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.PanelMenu.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelLogin.SuspendLayout()
        Me.PanelBeranda.SuspendLayout()
        CType(Me.ViewBerandaLaporan, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelKasir.SuspendLayout()
        CType(Me.viewKasir, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelStok.SuspendLayout()
        CType(Me.viewProduk, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PanelAkun.SuspendLayout()
        CType(Me.viewAkun, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'PanelMenu
        '
        Me.PanelMenu.AutoScroll = True
        Me.PanelMenu.BackColor = System.Drawing.Color.MidnightBlue
        Me.PanelMenu.Controls.Add(Me.btnLogout)
        Me.PanelMenu.Controls.Add(Me.btnAkun)
        Me.PanelMenu.Controls.Add(Me.btnStok)
        Me.PanelMenu.Controls.Add(Me.btnKasir)
        Me.PanelMenu.Controls.Add(Me.btnBeranda)
        Me.PanelMenu.Controls.Add(Me.Label1)
        Me.PanelMenu.Controls.Add(Me.PictureBox1)
        Me.PanelMenu.Dock = System.Windows.Forms.DockStyle.Left
        Me.PanelMenu.Location = New System.Drawing.Point(0, 0)
        Me.PanelMenu.Name = "PanelMenu"
        Me.PanelMenu.Size = New System.Drawing.Size(233, 536)
        Me.PanelMenu.TabIndex = 0
        '
        'btnLogout
        '
        Me.btnLogout.BackColor = System.Drawing.Color.Red
        Me.btnLogout.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogout.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLogout.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnLogout.Location = New System.Drawing.Point(0, 480)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(233, 56)
        Me.btnLogout.TabIndex = 4
        Me.btnLogout.Text = "Logout"
        Me.btnLogout.UseVisualStyleBackColor = False
        '
        'btnAkun
        '
        Me.btnAkun.BackColor = System.Drawing.Color.SlateBlue
        Me.btnAkun.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnAkun.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAkun.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAkun.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnAkun.Location = New System.Drawing.Point(0, 296)
        Me.btnAkun.Name = "btnAkun"
        Me.btnAkun.Size = New System.Drawing.Size(233, 67)
        Me.btnAkun.TabIndex = 3
        Me.btnAkun.Text = "Akun"
        Me.btnAkun.UseVisualStyleBackColor = False
        '
        'btnStok
        '
        Me.btnStok.BackColor = System.Drawing.Color.SlateBlue
        Me.btnStok.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnStok.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnStok.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStok.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnStok.Location = New System.Drawing.Point(0, 229)
        Me.btnStok.Name = "btnStok"
        Me.btnStok.Size = New System.Drawing.Size(233, 67)
        Me.btnStok.TabIndex = 2
        Me.btnStok.Text = "Produk"
        Me.btnStok.UseVisualStyleBackColor = False
        '
        'btnKasir
        '
        Me.btnKasir.BackColor = System.Drawing.Color.SlateBlue
        Me.btnKasir.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnKasir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnKasir.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnKasir.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnKasir.Location = New System.Drawing.Point(0, 162)
        Me.btnKasir.Name = "btnKasir"
        Me.btnKasir.Size = New System.Drawing.Size(233, 67)
        Me.btnKasir.TabIndex = 1
        Me.btnKasir.Text = "Kasir"
        Me.btnKasir.UseVisualStyleBackColor = False
        '
        'btnBeranda
        '
        Me.btnBeranda.BackColor = System.Drawing.Color.SlateBlue
        Me.btnBeranda.Dock = System.Windows.Forms.DockStyle.Top
        Me.btnBeranda.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBeranda.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBeranda.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnBeranda.Location = New System.Drawing.Point(0, 95)
        Me.btnBeranda.Name = "btnBeranda"
        Me.btnBeranda.Size = New System.Drawing.Size(233, 67)
        Me.btnBeranda.TabIndex = 0
        Me.btnBeranda.Text = "Beranda"
        Me.btnBeranda.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.MidnightBlue
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(22, 26)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 42)
        Me.Label1.TabIndex = 5
        Me.Label1.Text = "Rajasmart"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackColor = System.Drawing.Color.MidnightBlue
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Top
        Me.PictureBox1.Location = New System.Drawing.Point(0, 0)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(233, 95)
        Me.PictureBox1.TabIndex = 0
        Me.PictureBox1.TabStop = False
        '
        'PanelLogin
        '
        Me.PanelLogin.AutoScroll = True
        Me.PanelLogin.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.PanelLogin.Controls.Add(Me.btnLogin)
        Me.PanelLogin.Controls.Add(Me.txtPassword)
        Me.PanelLogin.Controls.Add(Me.txtUsername)
        Me.PanelLogin.Controls.Add(Me.Label4)
        Me.PanelLogin.Controls.Add(Me.Label3)
        Me.PanelLogin.Controls.Add(Me.Label2)
        Me.PanelLogin.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelLogin.Location = New System.Drawing.Point(233, 0)
        Me.PanelLogin.Name = "PanelLogin"
        Me.PanelLogin.Size = New System.Drawing.Size(781, 536)
        Me.PanelLogin.TabIndex = 1
        '
        'btnLogin
        '
        Me.btnLogin.BackColor = System.Drawing.SystemColors.Highlight
        Me.btnLogin.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnLogin.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.btnLogin.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.btnLogin.Location = New System.Drawing.Point(372, 391)
        Me.btnLogin.Name = "btnLogin"
        Me.btnLogin.Size = New System.Drawing.Size(219, 49)
        Me.btnLogin.TabIndex = 3
        Me.btnLogin.Text = "Log In"
        Me.btnLogin.UseVisualStyleBackColor = False
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.txtPassword.Location = New System.Drawing.Point(372, 333)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(219, 30)
        Me.txtPassword.TabIndex = 2
        '
        'txtUsername
        '
        Me.txtUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUsername.Location = New System.Drawing.Point(372, 226)
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.Size = New System.Drawing.Size(219, 30)
        Me.txtUsername.TabIndex = 1
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.ForeColor = System.Drawing.SystemColors.Control
        Me.Label4.Location = New System.Drawing.Point(366, 291)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(147, 36)
        Me.Label4.TabIndex = 0
        Me.Label4.Text = "Password"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.ForeColor = System.Drawing.SystemColors.Control
        Me.Label3.Location = New System.Drawing.Point(366, 187)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(150, 36)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Username"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.Control
        Me.Label2.Location = New System.Drawing.Point(330, 94)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(311, 69)
        Me.Label2.TabIndex = 0
        Me.Label2.Text = "Rajasmart"
        '
        'PanelBeranda
        '
        Me.PanelBeranda.AutoScroll = True
        Me.PanelBeranda.AutoScrollMargin = New System.Drawing.Size(0, 20)
        Me.PanelBeranda.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.PanelBeranda.Controls.Add(Me.DateBerandaAkhir)
        Me.PanelBeranda.Controls.Add(Me.DateBerandaAwal)
        Me.PanelBeranda.Controls.Add(Me.ViewBerandaLaporan)
        Me.PanelBeranda.Controls.Add(Me.txtBerandaIdAkun)
        Me.PanelBeranda.Controls.Add(Me.TextBox1)
        Me.PanelBeranda.Controls.Add(Me.BtnBerandaRefresh)
        Me.PanelBeranda.Controls.Add(Me.BtnBerandaFilter)
        Me.PanelBeranda.Controls.Add(Me.Label24)
        Me.PanelBeranda.Controls.Add(Me.Label25)
        Me.PanelBeranda.Controls.Add(Me.Label17)
        Me.PanelBeranda.Controls.Add(Me.Label5)
        Me.PanelBeranda.Controls.Add(Me.LabelBerandaJumlahTransaksi)
        Me.PanelBeranda.Controls.Add(Me.Label21)
        Me.PanelBeranda.Controls.Add(Me.Label18)
        Me.PanelBeranda.Controls.Add(Me.labelWelcome)
        Me.PanelBeranda.Controls.Add(Me.PictureBox2)
        Me.PanelBeranda.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelBeranda.Location = New System.Drawing.Point(233, 0)
        Me.PanelBeranda.Name = "PanelBeranda"
        Me.PanelBeranda.Size = New System.Drawing.Size(781, 536)
        Me.PanelBeranda.TabIndex = 4
        '
        'DateBerandaAkhir
        '
        Me.DateBerandaAkhir.Location = New System.Drawing.Point(342, 497)
        Me.DateBerandaAkhir.Name = "DateBerandaAkhir"
        Me.DateBerandaAkhir.Size = New System.Drawing.Size(181, 22)
        Me.DateBerandaAkhir.TabIndex = 15
        '
        'DateBerandaAwal
        '
        Me.DateBerandaAwal.Location = New System.Drawing.Point(68, 498)
        Me.DateBerandaAwal.Name = "DateBerandaAwal"
        Me.DateBerandaAwal.Size = New System.Drawing.Size(183, 22)
        Me.DateBerandaAwal.TabIndex = 15
        '
        'ViewBerandaLaporan
        '
        Me.ViewBerandaLaporan.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ViewBerandaLaporan.Location = New System.Drawing.Point(68, 528)
        Me.ViewBerandaLaporan.Name = "ViewBerandaLaporan"
        Me.ViewBerandaLaporan.RowHeadersWidth = 51
        Me.ViewBerandaLaporan.RowTemplate.Height = 24
        Me.ViewBerandaLaporan.Size = New System.Drawing.Size(642, 210)
        Me.ViewBerandaLaporan.TabIndex = 14
        '
        'txtBerandaIdAkun
        '
        Me.txtBerandaIdAkun.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtBerandaIdAkun.Location = New System.Drawing.Point(27, 80)
        Me.txtBerandaIdAkun.Name = "txtBerandaIdAkun"
        Me.txtBerandaIdAkun.Size = New System.Drawing.Size(90, 28)
        Me.txtBerandaIdAkun.TabIndex = 11
        Me.txtBerandaIdAkun.Visible = False
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(73, 759)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(253, 28)
        Me.TextBox1.TabIndex = 11
        '
        'BtnBerandaRefresh
        '
        Me.BtnBerandaRefresh.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnBerandaRefresh.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnBerandaRefresh.Location = New System.Drawing.Point(632, 490)
        Me.BtnBerandaRefresh.Name = "BtnBerandaRefresh"
        Me.BtnBerandaRefresh.Size = New System.Drawing.Size(78, 31)
        Me.BtnBerandaRefresh.TabIndex = 10
        Me.BtnBerandaRefresh.Text = "Refresh"
        Me.BtnBerandaRefresh.UseVisualStyleBackColor = False
        '
        'BtnBerandaFilter
        '
        Me.BtnBerandaFilter.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BtnBerandaFilter.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BtnBerandaFilter.Location = New System.Drawing.Point(542, 491)
        Me.BtnBerandaFilter.Name = "BtnBerandaFilter"
        Me.BtnBerandaFilter.Size = New System.Drawing.Size(78, 31)
        Me.BtnBerandaFilter.TabIndex = 10
        Me.BtnBerandaFilter.Text = "Filter"
        Me.BtnBerandaFilter.UseVisualStyleBackColor = False
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label24.Location = New System.Drawing.Point(117, 461)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(0, 20)
        Me.Label24.TabIndex = 9
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label25.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label25.Location = New System.Drawing.Point(264, 500)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(62, 20)
        Me.Label25.TabIndex = 9
        Me.Label25.Text = "Hingga"
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label17.Location = New System.Drawing.Point(70, 464)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(47, 20)
        Me.Label17.TabIndex = 9
        Me.Label17.Text = "Filter"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.BackColor = System.Drawing.Color.Indigo
        Me.Label5.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label5.Location = New System.Drawing.Point(227, 229)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(327, 42)
        Me.Label5.TabIndex = 8
        Me.Label5.Text = "Jumlah Transaksi"
        '
        'LabelBerandaJumlahTransaksi
        '
        Me.LabelBerandaJumlahTransaksi.AutoSize = True
        Me.LabelBerandaJumlahTransaksi.BackColor = System.Drawing.Color.Indigo
        Me.LabelBerandaJumlahTransaksi.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LabelBerandaJumlahTransaksi.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.LabelBerandaJumlahTransaksi.Location = New System.Drawing.Point(361, 288)
        Me.LabelBerandaJumlahTransaksi.Name = "LabelBerandaJumlahTransaksi"
        Me.LabelBerandaJumlahTransaksi.Size = New System.Drawing.Size(40, 42)
        Me.LabelBerandaJumlahTransaksi.TabIndex = 8
        Me.LabelBerandaJumlahTransaksi.Text = "0"
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label21.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label21.Location = New System.Drawing.Point(288, 400)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(163, 42)
        Me.Label21.TabIndex = 8
        Me.Label21.Text = "Laporan"
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label18.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label18.Location = New System.Drawing.Point(288, 23)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(167, 42)
        Me.Label18.TabIndex = 8
        Me.Label18.Text = "Beranda"
        '
        'labelWelcome
        '
        Me.labelWelcome.AutoSize = True
        Me.labelWelcome.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelWelcome.ForeColor = System.Drawing.SystemColors.Control
        Me.labelWelcome.Location = New System.Drawing.Point(143, 116)
        Me.labelWelcome.Name = "labelWelcome"
        Me.labelWelcome.Size = New System.Drawing.Size(152, 25)
        Me.labelWelcome.TabIndex = 0
        Me.labelWelcome.Text = "Selamat Datang"
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.Indigo
        Me.PictureBox2.Location = New System.Drawing.Point(-3, 215)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(761, 148)
        Me.PictureBox2.TabIndex = 13
        Me.PictureBox2.TabStop = False
        '
        'PanelKasir
        '
        Me.PanelKasir.AutoScroll = True
        Me.PanelKasir.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.PanelKasir.Controls.Add(Me.txtKasirIdTransaksi)
        Me.PanelKasir.Controls.Add(Me.viewKasir)
        Me.PanelKasir.Controls.Add(Me.btnKasirRefresh)
        Me.PanelKasir.Controls.Add(Me.txtKasirUang)
        Me.PanelKasir.Controls.Add(Me.txtKasirIdItem)
        Me.PanelKasir.Controls.Add(Me.txtKasirKode)
        Me.PanelKasir.Controls.Add(Me.btnKasirHapus)
        Me.PanelKasir.Controls.Add(Me.btnNewKasir)
        Me.PanelKasir.Controls.Add(Me.btnKasirTambah)
        Me.PanelKasir.Controls.Add(Me.btnKasirBayar)
        Me.PanelKasir.Controls.Add(Me.Label23)
        Me.PanelKasir.Controls.Add(Me.Label22)
        Me.PanelKasir.Controls.Add(Me.Label19)
        Me.PanelKasir.Controls.Add(Me.labelHargaTotal)
        Me.PanelKasir.Controls.Add(Me.Label6)
        Me.PanelKasir.Controls.Add(Me.Label20)
        Me.PanelKasir.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelKasir.Location = New System.Drawing.Point(233, 0)
        Me.PanelKasir.Name = "PanelKasir"
        Me.PanelKasir.Size = New System.Drawing.Size(781, 536)
        Me.PanelKasir.TabIndex = 1
        '
        'txtKasirIdTransaksi
        '
        Me.txtKasirIdTransaksi.Enabled = False
        Me.txtKasirIdTransaksi.Location = New System.Drawing.Point(27, 40)
        Me.txtKasirIdTransaksi.Name = "txtKasirIdTransaksi"
        Me.txtKasirIdTransaksi.Size = New System.Drawing.Size(100, 22)
        Me.txtKasirIdTransaksi.TabIndex = 14
        '
        'viewKasir
        '
        Me.viewKasir.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewKasir.Location = New System.Drawing.Point(27, 68)
        Me.viewKasir.Name = "viewKasir"
        Me.viewKasir.RowHeadersWidth = 51
        Me.viewKasir.RowTemplate.Height = 24
        Me.viewKasir.Size = New System.Drawing.Size(498, 454)
        Me.viewKasir.TabIndex = 13
        '
        'btnKasirRefresh
        '
        Me.btnKasirRefresh.Location = New System.Drawing.Point(326, 35)
        Me.btnKasirRefresh.Name = "btnKasirRefresh"
        Me.btnKasirRefresh.Size = New System.Drawing.Size(75, 23)
        Me.btnKasirRefresh.TabIndex = 12
        Me.btnKasirRefresh.Text = "Refresh"
        Me.btnKasirRefresh.UseVisualStyleBackColor = True
        '
        'txtKasirUang
        '
        Me.txtKasirUang.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKasirUang.Location = New System.Drawing.Point(542, 391)
        Me.txtKasirUang.Name = "txtKasirUang"
        Me.txtKasirUang.Size = New System.Drawing.Size(227, 28)
        Me.txtKasirUang.TabIndex = 11
        '
        'txtKasirIdItem
        '
        Me.txtKasirIdItem.Enabled = False
        Me.txtKasirIdItem.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKasirIdItem.Location = New System.Drawing.Point(542, 95)
        Me.txtKasirIdItem.Name = "txtKasirIdItem"
        Me.txtKasirIdItem.Size = New System.Drawing.Size(55, 28)
        Me.txtKasirIdItem.TabIndex = 11
        '
        'txtKasirKode
        '
        Me.txtKasirKode.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtKasirKode.Location = New System.Drawing.Point(613, 95)
        Me.txtKasirKode.Name = "txtKasirKode"
        Me.txtKasirKode.Size = New System.Drawing.Size(156, 28)
        Me.txtKasirKode.TabIndex = 11
        '
        'btnKasirHapus
        '
        Me.btnKasirHapus.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnKasirHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnKasirHapus.Location = New System.Drawing.Point(670, 145)
        Me.btnKasirHapus.Name = "btnKasirHapus"
        Me.btnKasirHapus.Size = New System.Drawing.Size(99, 29)
        Me.btnKasirHapus.TabIndex = 10
        Me.btnKasirHapus.Text = "Hapus"
        Me.btnKasirHapus.UseVisualStyleBackColor = False
        '
        'btnNewKasir
        '
        Me.btnNewKasir.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnNewKasir.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnNewKasir.Location = New System.Drawing.Point(420, 29)
        Me.btnNewKasir.Name = "btnNewKasir"
        Me.btnNewKasir.Size = New System.Drawing.Size(63, 29)
        Me.btnNewKasir.TabIndex = 10
        Me.btnNewKasir.Text = "New"
        Me.btnNewKasir.UseVisualStyleBackColor = False
        Me.btnNewKasir.Visible = False
        '
        'btnKasirTambah
        '
        Me.btnKasirTambah.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnKasirTambah.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnKasirTambah.Location = New System.Drawing.Point(542, 145)
        Me.btnKasirTambah.Name = "btnKasirTambah"
        Me.btnKasirTambah.Size = New System.Drawing.Size(99, 29)
        Me.btnKasirTambah.TabIndex = 10
        Me.btnKasirTambah.Text = "Tambah"
        Me.btnKasirTambah.UseVisualStyleBackColor = False
        '
        'btnKasirBayar
        '
        Me.btnKasirBayar.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnKasirBayar.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnKasirBayar.Location = New System.Drawing.Point(542, 436)
        Me.btnKasirBayar.Name = "btnKasirBayar"
        Me.btnKasirBayar.Size = New System.Drawing.Size(227, 86)
        Me.btnKasirBayar.TabIndex = 10
        Me.btnKasirBayar.Text = "Bayar"
        Me.btnKasirBayar.UseVisualStyleBackColor = False
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label23.Location = New System.Drawing.Point(538, 67)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(59, 20)
        Me.Label23.TabIndex = 9
        Me.Label23.Text = "Id Item"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label22.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label22.Location = New System.Drawing.Point(538, 368)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(107, 20)
        Me.Label22.TabIndex = 9
        Me.Label22.Text = "Jumlah Uang"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label19.Location = New System.Drawing.Point(609, 66)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(104, 20)
        Me.Label19.TabIndex = 9
        Me.Label19.Text = "Kode Produk"
        '
        'labelHargaTotal
        '
        Me.labelHargaTotal.AutoSize = True
        Me.labelHargaTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 18.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.labelHargaTotal.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.labelHargaTotal.Location = New System.Drawing.Point(540, 260)
        Me.labelHargaTotal.Name = "labelHargaTotal"
        Me.labelHargaTotal.Size = New System.Drawing.Size(173, 36)
        Me.labelHargaTotal.TabIndex = 8
        Me.labelHargaTotal.Text = "100000 Rp"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label6.Location = New System.Drawing.Point(604, 199)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(106, 42)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Total"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label20.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label20.Location = New System.Drawing.Point(201, 23)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(108, 42)
        Me.Label20.TabIndex = 8
        Me.Label20.Text = "Kasir"
        '
        'PanelStok
        '
        Me.PanelStok.AutoScroll = True
        Me.PanelStok.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.PanelStok.Controls.Add(Me.btnProdukRefresh)
        Me.PanelStok.Controls.Add(Me.txtProdukHarga)
        Me.PanelStok.Controls.Add(Me.txtProdukJumlah)
        Me.PanelStok.Controls.Add(Me.txtProdukNama)
        Me.PanelStok.Controls.Add(Me.txtProdukKode)
        Me.PanelStok.Controls.Add(Me.btnProdukHapus)
        Me.PanelStok.Controls.Add(Me.btnProdukEdit)
        Me.PanelStok.Controls.Add(Me.btnProdukSimpan)
        Me.PanelStok.Controls.Add(Me.Label16)
        Me.PanelStok.Controls.Add(Me.Label15)
        Me.PanelStok.Controls.Add(Me.Label14)
        Me.PanelStok.Controls.Add(Me.Label8)
        Me.PanelStok.Controls.Add(Me.viewProduk)
        Me.PanelStok.Controls.Add(Me.Label13)
        Me.PanelStok.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelStok.Location = New System.Drawing.Point(233, 0)
        Me.PanelStok.Name = "PanelStok"
        Me.PanelStok.Size = New System.Drawing.Size(781, 536)
        Me.PanelStok.TabIndex = 1
        '
        'btnProdukRefresh
        '
        Me.btnProdukRefresh.Location = New System.Drawing.Point(576, 47)
        Me.btnProdukRefresh.Name = "btnProdukRefresh"
        Me.btnProdukRefresh.Size = New System.Drawing.Size(75, 23)
        Me.btnProdukRefresh.TabIndex = 7
        Me.btnProdukRefresh.Text = "Refresh"
        Me.btnProdukRefresh.UseVisualStyleBackColor = True
        '
        'txtProdukHarga
        '
        Me.txtProdukHarga.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProdukHarga.Location = New System.Drawing.Point(457, 402)
        Me.txtProdukHarga.Name = "txtProdukHarga"
        Me.txtProdukHarga.Size = New System.Drawing.Size(253, 28)
        Me.txtProdukHarga.TabIndex = 6
        '
        'txtProdukJumlah
        '
        Me.txtProdukJumlah.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProdukJumlah.Location = New System.Drawing.Point(60, 403)
        Me.txtProdukJumlah.Name = "txtProdukJumlah"
        Me.txtProdukJumlah.Size = New System.Drawing.Size(253, 28)
        Me.txtProdukJumlah.TabIndex = 6
        '
        'txtProdukNama
        '
        Me.txtProdukNama.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProdukNama.Location = New System.Drawing.Point(457, 333)
        Me.txtProdukNama.Name = "txtProdukNama"
        Me.txtProdukNama.Size = New System.Drawing.Size(253, 28)
        Me.txtProdukNama.TabIndex = 6
        '
        'txtProdukKode
        '
        Me.txtProdukKode.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtProdukKode.Location = New System.Drawing.Point(60, 333)
        Me.txtProdukKode.Name = "txtProdukKode"
        Me.txtProdukKode.Size = New System.Drawing.Size(253, 28)
        Me.txtProdukKode.TabIndex = 6
        '
        'btnProdukHapus
        '
        Me.btnProdukHapus.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnProdukHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProdukHapus.Location = New System.Drawing.Point(489, 472)
        Me.btnProdukHapus.Name = "btnProdukHapus"
        Me.btnProdukHapus.Size = New System.Drawing.Size(203, 53)
        Me.btnProdukHapus.TabIndex = 4
        Me.btnProdukHapus.Text = "Hapus"
        Me.btnProdukHapus.UseVisualStyleBackColor = False
        '
        'btnProdukEdit
        '
        Me.btnProdukEdit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnProdukEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProdukEdit.Location = New System.Drawing.Point(280, 472)
        Me.btnProdukEdit.Name = "btnProdukEdit"
        Me.btnProdukEdit.Size = New System.Drawing.Size(203, 53)
        Me.btnProdukEdit.TabIndex = 4
        Me.btnProdukEdit.Text = "Edit"
        Me.btnProdukEdit.UseVisualStyleBackColor = False
        '
        'btnProdukSimpan
        '
        Me.btnProdukSimpan.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnProdukSimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnProdukSimpan.Location = New System.Drawing.Point(71, 472)
        Me.btnProdukSimpan.Name = "btnProdukSimpan"
        Me.btnProdukSimpan.Size = New System.Drawing.Size(203, 53)
        Me.btnProdukSimpan.TabIndex = 4
        Me.btnProdukSimpan.Text = "Simpan"
        Me.btnProdukSimpan.UseVisualStyleBackColor = False
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label16.Location = New System.Drawing.Point(453, 380)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(55, 20)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Harga"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label15.Location = New System.Drawing.Point(56, 380)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(63, 20)
        Me.Label15.TabIndex = 3
        Me.Label15.Text = "Jumlah"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label14.Location = New System.Drawing.Point(453, 301)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(61, 20)
        Me.Label14.TabIndex = 3
        Me.Label14.Text = "Produk"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label8.Location = New System.Drawing.Point(56, 303)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 20)
        Me.Label8.TabIndex = 3
        Me.Label8.Text = "Kode Produk"
        '
        'viewProduk
        '
        Me.viewProduk.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewProduk.Location = New System.Drawing.Point(92, 87)
        Me.viewProduk.Name = "viewProduk"
        Me.viewProduk.RowHeadersWidth = 51
        Me.viewProduk.RowTemplate.Height = 24
        Me.viewProduk.Size = New System.Drawing.Size(559, 182)
        Me.viewProduk.TabIndex = 2
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label13.Location = New System.Drawing.Point(251, 35)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(237, 42)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "Data Produk"
        '
        'PanelAkun
        '
        Me.PanelAkun.AutoScroll = True
        Me.PanelAkun.AutoScrollMargin = New System.Drawing.Size(0, 20)
        Me.PanelAkun.BackColor = System.Drawing.Color.DarkSlateBlue
        Me.PanelAkun.Controls.Add(Me.btnAkunRefresh)
        Me.PanelAkun.Controls.Add(Me.txtAkunId)
        Me.PanelAkun.Controls.Add(Me.txtAkunJabatan)
        Me.PanelAkun.Controls.Add(Me.txtAkunPassword)
        Me.PanelAkun.Controls.Add(Me.txtAkunUsername)
        Me.PanelAkun.Controls.Add(Me.txtAkunNama)
        Me.PanelAkun.Controls.Add(Me.btnAkunHapus)
        Me.PanelAkun.Controls.Add(Me.btnAkunEdit)
        Me.PanelAkun.Controls.Add(Me.btnAkunSimpan)
        Me.PanelAkun.Controls.Add(Me.viewAkun)
        Me.PanelAkun.Controls.Add(Me.Label12)
        Me.PanelAkun.Controls.Add(Me.Label11)
        Me.PanelAkun.Controls.Add(Me.Label10)
        Me.PanelAkun.Controls.Add(Me.Label9)
        Me.PanelAkun.Controls.Add(Me.Label7)
        Me.PanelAkun.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PanelAkun.Location = New System.Drawing.Point(233, 0)
        Me.PanelAkun.Name = "PanelAkun"
        Me.PanelAkun.Size = New System.Drawing.Size(781, 536)
        Me.PanelAkun.TabIndex = 0
        '
        'btnAkunRefresh
        '
        Me.btnAkunRefresh.Location = New System.Drawing.Point(598, 35)
        Me.btnAkunRefresh.Name = "btnAkunRefresh"
        Me.btnAkunRefresh.Size = New System.Drawing.Size(75, 23)
        Me.btnAkunRefresh.TabIndex = 10
        Me.btnAkunRefresh.Text = "Refresh"
        Me.btnAkunRefresh.UseVisualStyleBackColor = True
        '
        'txtAkunId
        '
        Me.txtAkunId.Location = New System.Drawing.Point(20, 362)
        Me.txtAkunId.Name = "txtAkunId"
        Me.txtAkunId.Size = New System.Drawing.Size(49, 22)
        Me.txtAkunId.TabIndex = 9
        Me.txtAkunId.Visible = False
        '
        'txtAkunJabatan
        '
        Me.txtAkunJabatan.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAkunJabatan.Location = New System.Drawing.Point(75, 563)
        Me.txtAkunJabatan.Name = "txtAkunJabatan"
        Me.txtAkunJabatan.Size = New System.Drawing.Size(599, 28)
        Me.txtAkunJabatan.TabIndex = 8
        '
        'txtAkunPassword
        '
        Me.txtAkunPassword.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAkunPassword.Location = New System.Drawing.Point(75, 497)
        Me.txtAkunPassword.Name = "txtAkunPassword"
        Me.txtAkunPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtAkunPassword.Size = New System.Drawing.Size(599, 28)
        Me.txtAkunPassword.TabIndex = 7
        '
        'txtAkunUsername
        '
        Me.txtAkunUsername.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAkunUsername.Location = New System.Drawing.Point(74, 427)
        Me.txtAkunUsername.Name = "txtAkunUsername"
        Me.txtAkunUsername.Size = New System.Drawing.Size(599, 28)
        Me.txtAkunUsername.TabIndex = 6
        '
        'txtAkunNama
        '
        Me.txtAkunNama.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAkunNama.Location = New System.Drawing.Point(75, 362)
        Me.txtAkunNama.Name = "txtAkunNama"
        Me.txtAkunNama.Size = New System.Drawing.Size(599, 28)
        Me.txtAkunNama.TabIndex = 5
        '
        'btnAkunHapus
        '
        Me.btnAkunHapus.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAkunHapus.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAkunHapus.Location = New System.Drawing.Point(484, 636)
        Me.btnAkunHapus.Name = "btnAkunHapus"
        Me.btnAkunHapus.Size = New System.Drawing.Size(203, 53)
        Me.btnAkunHapus.TabIndex = 4
        Me.btnAkunHapus.Text = "Hapus"
        Me.btnAkunHapus.UseVisualStyleBackColor = False
        '
        'btnAkunEdit
        '
        Me.btnAkunEdit.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAkunEdit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAkunEdit.Location = New System.Drawing.Point(275, 636)
        Me.btnAkunEdit.Name = "btnAkunEdit"
        Me.btnAkunEdit.Size = New System.Drawing.Size(203, 53)
        Me.btnAkunEdit.TabIndex = 3
        Me.btnAkunEdit.Text = "Edit"
        Me.btnAkunEdit.UseVisualStyleBackColor = False
        '
        'btnAkunSimpan
        '
        Me.btnAkunSimpan.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.btnAkunSimpan.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnAkunSimpan.Location = New System.Drawing.Point(66, 636)
        Me.btnAkunSimpan.Name = "btnAkunSimpan"
        Me.btnAkunSimpan.Size = New System.Drawing.Size(203, 53)
        Me.btnAkunSimpan.TabIndex = 2
        Me.btnAkunSimpan.Text = "Simpan"
        Me.btnAkunSimpan.UseVisualStyleBackColor = False
        '
        'viewAkun
        '
        Me.viewAkun.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.viewAkun.Location = New System.Drawing.Point(57, 76)
        Me.viewAkun.Name = "viewAkun"
        Me.viewAkun.RowHeadersWidth = 51
        Me.viewAkun.RowTemplate.Height = 24
        Me.viewAkun.Size = New System.Drawing.Size(617, 249)
        Me.viewAkun.TabIndex = 1
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label12.Location = New System.Drawing.Point(70, 538)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(68, 20)
        Me.Label12.TabIndex = 0
        Me.Label12.Text = "Jabatan"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label11.Location = New System.Drawing.Point(70, 475)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(83, 20)
        Me.Label11.TabIndex = 0
        Me.Label11.Text = "Password"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label10.Location = New System.Drawing.Point(69, 404)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(86, 20)
        Me.Label10.TabIndex = 0
        Me.Label10.Text = "Username"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label9.Location = New System.Drawing.Point(70, 339)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(121, 20)
        Me.Label9.TabIndex = 0
        Me.Label9.Text = "Nama Lengkap"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label7.Location = New System.Drawing.Point(268, 26)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(220, 42)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Panel Akun"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1014, 536)
        Me.Controls.Add(Me.PanelKasir)
        Me.Controls.Add(Me.PanelBeranda)
        Me.Controls.Add(Me.PanelLogin)
        Me.Controls.Add(Me.PanelStok)
        Me.Controls.Add(Me.PanelAkun)
        Me.Controls.Add(Me.PanelMenu)
        Me.MaximizeBox = False
        Me.Name = "Form1"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "KASIR LKS"
        Me.PanelMenu.ResumeLayout(False)
        Me.PanelMenu.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelLogin.ResumeLayout(False)
        Me.PanelLogin.PerformLayout()
        Me.PanelBeranda.ResumeLayout(False)
        Me.PanelBeranda.PerformLayout()
        CType(Me.ViewBerandaLaporan, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelKasir.ResumeLayout(False)
        Me.PanelKasir.PerformLayout()
        CType(Me.viewKasir, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelStok.ResumeLayout(False)
        Me.PanelStok.PerformLayout()
        CType(Me.viewProduk, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PanelAkun.ResumeLayout(False)
        Me.PanelAkun.PerformLayout()
        CType(Me.viewAkun, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents PanelMenu As Panel
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents btnLogout As Button
    Friend WithEvents btnAkun As Button
    Friend WithEvents btnStok As Button
    Friend WithEvents btnKasir As Button
    Friend WithEvents btnBeranda As Button
    Friend WithEvents PanelLogin As Panel
    Friend WithEvents Label2 As Label
    Friend WithEvents txtPassword As TextBox
    Friend WithEvents txtUsername As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnLogin As Button
    Friend WithEvents PanelBeranda As Panel
    Friend WithEvents labelWelcome As Label
    Friend WithEvents PanelKasir As Panel
    Friend WithEvents PanelStok As Panel
    Friend WithEvents PanelAkun As Panel
    Friend WithEvents Label7 As Label
    Friend WithEvents viewAkun As DataGridView
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents txtAkunJabatan As TextBox
    Friend WithEvents txtAkunPassword As TextBox
    Friend WithEvents txtAkunUsername As TextBox
    Friend WithEvents txtAkunNama As TextBox
    Friend WithEvents btnAkunHapus As Button
    Friend WithEvents btnAkunEdit As Button
    Friend WithEvents btnAkunSimpan As Button
    Friend WithEvents txtAkunId As TextBox
    Friend WithEvents btnAkunRefresh As Button
    Friend WithEvents viewProduk As DataGridView
    Friend WithEvents Label13 As Label
    Friend WithEvents btnProdukEdit As Button
    Friend WithEvents btnProdukSimpan As Button
    Friend WithEvents Label8 As Label
    Friend WithEvents txtProdukHarga As TextBox
    Friend WithEvents txtProdukJumlah As TextBox
    Friend WithEvents txtProdukNama As TextBox
    Friend WithEvents txtProdukKode As TextBox
    Friend WithEvents btnProdukHapus As Button
    Friend WithEvents Label16 As Label
    Friend WithEvents Label15 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents btnProdukRefresh As Button
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents BtnBerandaFilter As Button
    Friend WithEvents Label17 As Label
    Friend WithEvents Label18 As Label
    Friend WithEvents viewKasir As DataGridView
    Friend WithEvents btnKasirRefresh As Button
    Friend WithEvents txtKasirUang As TextBox
    Friend WithEvents txtKasirKode As TextBox
    Friend WithEvents btnKasirHapus As Button
    Friend WithEvents btnNewKasir As Button
    Friend WithEvents btnKasirTambah As Button
    Friend WithEvents btnKasirBayar As Button
    Friend WithEvents Label22 As Label
    Friend WithEvents Label19 As Label
    Friend WithEvents labelHargaTotal As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label20 As Label
    Friend WithEvents txtKasirIdItem As TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents txtKasirIdTransaksi As TextBox
    Friend WithEvents DateBerandaAkhir As DateTimePicker
    Friend WithEvents DateBerandaAwal As DateTimePicker
    Friend WithEvents ViewBerandaLaporan As DataGridView
    Friend WithEvents Label24 As Label
    Friend WithEvents Label25 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents LabelBerandaJumlahTransaksi As Label
    Friend WithEvents Label21 As Label
    Friend WithEvents PictureBox2 As PictureBox
    Friend WithEvents txtBerandaIdAkun As TextBox
    Friend WithEvents BtnBerandaRefresh As Button
End Class
